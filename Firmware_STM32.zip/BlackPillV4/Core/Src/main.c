/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "ds18b20.h"
//#define CCR1_MIN 1150
//#define CCR1_MAX 6773

#define CCR1_MIN 2709
#define CCR1_MAX 3420
OneWire_t OneWire;   // Structure pour la communication OneWire
uint8_t ROM[8];      // Adresse du capteur DS18B20
float temperature;   // Variable pour stocker la temp�rature
int tempInt = 0 ;
int tempDec = 0 ;
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
SPI_HandleTypeDef hspi2;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI2_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);
static void MX_USART2_UART_Init(void);
/* USER CODE BEGIN PFP */
void Read_Temperature(void);
void traiter_positionMoteurHaut(float y);
void traiter_positionMoteurGauche(float x);
void traiter_positionMoteurDroit(float h);
void allumer_laser(float laser);
void allumer_led(float led);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI2_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */
  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);  // Moteur  gauche (PB0)
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);  // Moteur sup�rieur (PA6)
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);  // Moteur droit (PA7)
        htim2.Instance->CCR2 = CCR1_MAX;
        htim3.Instance->CCR1 = CCR1_MAX;
        htim3.Instance->CCR2 = CCR1_MAX;
        HAL_Delay(3000);
        htim2.Instance->CCR2 = CCR1_MIN;
        htim3.Instance->CCR1 = CCR1_MIN;
        htim3.Instance->CCR2 = CCR1_MIN;
        HAL_Delay(3000);
    /* USER CODE END 2 */
  #define LIS3DH_CS_LOW()  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET)
  #define LIS3DH_CS_HIGH() HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET)

  /* LIS3DH SPI Communication */
  uint8_t LIS3DH_ReadReg(uint8_t reg) {
      uint8_t txData[2] = { reg | 0x80, 0x00 };  // 0x80 = lecture
      uint8_t rxData[2] = { 0 };

      LIS3DH_CS_LOW();
      HAL_SPI_TransmitReceive(&hspi2, txData, rxData, 2, HAL_MAX_DELAY);
      LIS3DH_CS_HIGH();

      return rxData[1];  // Le second octet contient la r�ponse
  }

  void LIS3DH_WriteReg(uint8_t reg, uint8_t data) {
      uint8_t txData[2] = { reg & 0x7F, data };  // 0x7F = �criture
      LIS3DH_CS_LOW();
      HAL_SPI_Transmit(&hspi2, txData, 2, HAL_MAX_DELAY);
      LIS3DH_CS_HIGH();
  }

  void LIS3DH_Init(void) {
      // CTRL_REG1: 100 Hz, XYZ enable
      LIS3DH_WriteReg(0x20, 0x67);
      LIS3DH_WriteReg(0x23, 0x10);  // �4g, High Resolution, BDU d�sactiv�


  }

  int16_t LIS3DH_ReadAxis(uint8_t regL, uint8_t regH) {
      uint8_t lowByte = LIS3DH_ReadReg(regL);
      uint8_t highByte = LIS3DH_ReadReg(regH);
      return (int16_t)((highByte << 8) | lowByte);  // Combinaison des octets
  }

  // Initialisation du capteur DS18B20
        OneWire_Init(&OneWire, DS18B20_GPIO_Port, DS18B20_Pin);

        // V�rification de la pr�sence du capteur
       if (OneWire_First(&OneWire)) {
            OneWire_GetFullROM(&OneWire, ROM);
            DS18B20_SetResolution(&OneWire, ROM, DS18B20_Resolution_12bits); }

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
        char buffert[50];
        char buffer1[10];
        char buffer2[10];
        char buffer3[10];
        char buffer4[10];
        char buffer5[10];
 	  if (HAL_UART_Receive(&huart2, (uint8_t*)buffert, sizeof(buffert),1000) == HAL_OK) {
 		  char* token = strtok(buffert, ","); // S�pare le premier token (avant la virgule)
 		          if (token != NULL) {
 		              strcpy(buffer1, token);  // Copie le premier token dans buffer
 		          }

 		          token = strtok(NULL, ",");  // S�pare le deuxi�me token (apr�s la premi�re virgule)
 		          if (token != NULL) {
 		              strcpy(buffer2, token);  // Copie le deuxi�me token dans buffer1
 		          }

 		          token = strtok(NULL, ",");  // S�pare le troisi�me token (apr�s la deuxi�me virgule)
 		          if (token != NULL) {
 		              strcpy(buffer3, token);  // Copie le troisi�me token dans buffer3
 		          }
 		          token = strtok(NULL, ",");  // S�pare le quatri�me token (apr�s la troisi�me virgule)
 		          if (token != NULL) {
 		              strcpy(buffer4, token);  // Copie le quatri�me token dans buffer4
 		          }
 		          token = strtok(NULL, ",");  // S�pare le quatri�me token (apr�s la troisi�me virgule)
 		          if (token != NULL) {
 		              strcpy(buffer5, token);  // Copie le quatri�me token dans buffer5

 		          }
         float joy = atof(buffer1);  // Convertir la cha�ne re�ue en float
         traiter_positionMoteurHaut(joy);     // Traiter la position du servo en fonction du bouton RT
         float rt_value = atof(buffer2);  // Convertir la cha�ne re�ue en float
         traiter_positionMoteurGauche(rt_value);
   	  float lt_value = atof(buffer3);  // Convertir la cha�ne re�ue en float
   	  traiter_positionMoteurDroit(lt_value);     // Traiter la position du servo en fonction du bouton RT
         float laser = atof(buffer4);
         allumer_laser(laser);
         float led = atof(buffer5);
   	  allumer_led(led);
   	  HAL_Delay(50);
 		  Read_Temperature();
 	      LIS3DH_Init();

 	    // Lire les valeurs brutes des axes
 	      	int16_t x = LIS3DH_ReadAxis(0x28, 0x29);
 	      	int16_t y = LIS3DH_ReadAxis(0x2A, 0x2B);
 	      	int16_t z = LIS3DH_ReadAxis(0x2C, 0x2D);

 	      	// Conversion en mg (sensibilit� pour �4g)
 	      	int x_mg = (x * 122) / 1000;  // 0.000122 * 1000 = 122 / 1000000
 	      	int y_mg = (y * 122) / 1000;
 	      	int z_mg = (z * 122) / 1000;

 	    char final_msg[300];
 	    snprintf(final_msg, sizeof(final_msg), "Temp: %d.%02d�C | X: %d mg | Y: %d mg | Z: %d mg \r\n",tempInt,tempDec, x_mg, y_mg, z_mg);
 	    HAL_UART_Transmit(&huart2, (uint8_t*)final_msg, strlen(final_msg),100);

 	  }
  }
  /* USER CODE END 3 */
}
// Fonction pour lire la temp�rature et l'envoyer via UART2
      void Read_Temperature(void)
      {
      	if (DS18B20_Start(&OneWire, ROM)) {
      	        HAL_Delay(750); // Attendre la conversion

      	        uint8_t rawData[9]; // Stockage des donn�es brutes

      	        OneWire_Reset(&OneWire);
      	        OneWire_SelectWithPointer(&OneWire, ROM);
      	        OneWire_WriteByte(&OneWire, ONEWIRE_CMD_RSCRATCHPAD);

      	        for (int i = 0; i < 9; i++) {
      	            rawData[i] = OneWire_ReadByte(&OneWire);
      	        }

      	        // Conversion de la temp�rature
      	        int16_t tempRaw = (rawData[1] << 8) | rawData[0]; // MSB << 8 | LSB
      	        float temperature = tempRaw * 0.0625;
      	        // Affichage de la temp�rature
      	           tempInt = (int)temperature;  // Partie enti�re
      	           tempDec = (int)((temperature - tempInt) * 100); // Partie d�cimale (2 chiffres)

      	    }
      }
      void traiter_positionMoteurHaut(float y)
      {
          // V�rification du mappage de la valeur
          if (y < 0.0) y = 0.0;  // S'assurer que y est au moins 0.0
          if (y > 1.0) y = 1.0;  // S'assurer que y ne d�passe pas 1.0

          // Calcul du PWM bas� sur la valeur de position (y)
          uint16_t ccr1_value = (uint16_t)(CCR1_MIN + (y * (CCR1_MAX - CCR1_MIN)));
          // Mise � jour du servo avec la nouvelle valeur
              htim3.Instance->CCR1 = ccr1_value;

      }
      void traiter_positionMoteurGauche(float x)
      {
          // Mappage de y
      	uint16_t ccr2_value = (uint16_t)(CCR1_MIN + (x * (CCR1_MAX - CCR1_MIN)));

          // Mise � jour du PWM
          htim3.Instance->CCR2 = ccr2_value;

      }

      void traiter_positionMoteurDroit(float h)
      {

          // V�rification du mappage de la valeur
          if (h < 0.0) h = 0.0;  // S'assurer que y est au moins 0.0
          if (h > 1.0) h = 1.0;  // S'assurer que y ne d�passe pas 1.0

          // Calcul du PWM bas� sur la valeur de position (y)
          uint16_t ccr4_value = (uint16_t)(CCR1_MIN + (h * (CCR1_MAX - CCR1_MIN)));

          // Mise � jour du servo avec la nouvelle valeur
          htim2.Instance->CCR2 = ccr4_value;
      }
      void allumer_laser(float laser)
      {
         if (laser == 1.00f)  // Si '1', on allume le laser
        {
          HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_SET);  // Activer le laser (modifiez le pin selon votre configuration)
        }
         else if (laser == 0.00f)  // Si '0', on �teint le laser
        {
          HAL_GPIO_WritePin(GPIOB, GPIO_PIN_9, GPIO_PIN_RESET);  // D�sactiver le laser
        }

      }
      void allumer_led(float led)
      {
        if (led== 1.00f)  // Si '1', on allume le laser
        {
          HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_SET);
        }
        else if (led == 0.00f)  // Si '0', on �teint le laser
        {
          HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8, GPIO_PIN_RESET);
         }
      }

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SPI2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI2_Init(void)
{

  /* USER CODE BEGIN SPI2_Init 0 */

  /* USER CODE END SPI2_Init 0 */

  /* USER CODE BEGIN SPI2_Init 1 */

  /* USER CODE END SPI2_Init 1 */
  /* SPI2 parameter configuration*/
  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi2.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi2.Init.NSS = SPI_NSS_SOFT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI2_Init 2 */

  /* USER CODE END SPI2_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 84-1;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 0xFFFF;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim1, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 30;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 54199;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 30;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 54199;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1|GPIO_PIN_4, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_8|GPIO_PIN_9, GPIO_PIN_RESET);

  /*Configure GPIO pin : PA1 */
  GPIO_InitStruct.Pin = GPIO_PIN_1;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_OD;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : PA4 */
  GPIO_InitStruct.Pin = GPIO_PIN_4;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB8 PB9 */
  GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
